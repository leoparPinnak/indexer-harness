/**
 * Shellbox Daemon Manager — Oversees the lifecycle of the independent
 * Shellbox background service from within DSH.
 *
 * Spawns the daemon in its own isolated process, discovers its listening port,
 * checks health, and transparently restarts it on unexpected exits so that
 * streaming spikes or emulator crashes never affect DSH.
 *
 * @module @deepseek-ai/dsh-web-app/shellbox-daemon-manager
 */
import { type IncomingMessage, type ServerResponse } from 'node:http';
import { type DaemonLogger } from './shellbox-daemon.ts';
export interface ShellboxDaemonManagerOptions {
    port?: number | undefined;
    log: DaemonLogger;
    daemonScript?: string | undefined;
}
export declare class ShellboxDaemonManager {
    private child;
    private activePort;
    private startingPromise;
    private stopping;
    private readonly targetPort;
    private readonly log;
    private readonly scriptPath;
    constructor(options: ShellboxDaemonManagerOptions);
    /** True if the daemon child process is currently alive. */
    isActive(): boolean;
    /** Return the currently discovered daemon base URL, or undefined if not active. */
    getBaseUrl(): string | undefined;
    /** Return the currently active port, or undefined if not active. */
    getPort(): number | undefined;
    /**
     * Ensure the daemon is running and healthy.
     * If already healthy, returns immediately. Otherwise spawns and polls /health.
     */
    ensureRunning(): Promise<{
        port: number;
        url: string;
    }>;
    /**
     * Ping the /health endpoint of the daemon.
     */
    private pingHealth;
    /**
     * Spawn the daemon subprocess and wait until it is listening and passes health check.
     */
    private startDaemon;
    /**
     * Forward a JSON API request from DSH to the daemon.
     * Catches network dropouts cleanly and sends HTTP 502 without crashing DSH.
     */
    forwardJson(req: IncomingMessage, res: ServerResponse, targetPath: string, bodyOverride?: unknown): Promise<void>;
    /**
     * Fetch a JSON endpoint on the daemon directly (e.g. for tools).
     */
    fetchJson<T = unknown>(targetPath: string, options?: {
        method?: string;
        body?: unknown;
    }): Promise<T>;
    /**
     * Stop the daemon process cleanly.
     */
    stop(): Promise<void>;
}
//# sourceMappingURL=shellbox-daemon-manager.d.ts.map