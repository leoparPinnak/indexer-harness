/**
 * @deepseek-ai/dsh-deamon — the Deamon bundle's runtime glue plugin. It
 * owns the isolated private Windows desktop feature end to end: the sandbox
 * route surface and WebSocket frame feed ([`registerSandboxRoutes`]), the
 * shared helper daemon (`src/deamon*.ts`), the
 * `sandbox/sandbox-host.ps1` capture helper, the model-facing
 * `shellbox_launch`, `shellbox_state`, and `shellbox_input` tools, the
 * bundled `shellbox` skill, and the `app:shellbox-surface` and
 * `app:shellbox-changes` prompt sections. The browser pane is the
 * `ui-sandbox-view` row in this bundle's patch.
 * @module @deepseek-ai/dsh-deamon
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable Cordis plugin name. */
export declare const name = "deamon";
/** Services required before the Deamon bridge can mount. */
export declare const inject: string[];
/** Plugin config: composed deployment settings for the Shellbox feature. */
export interface Config {
    /**
     * Register the model-visible surface context (the `app:shellbox-surface`
     * prompt section). A non-interactive layer can turn it off when its user is
     * not in the GUI, so the orientation text would be false.
     */
    surfaceContext: boolean;
}
export declare const Config: z<Config>;
/** Mount the Shellbox routes, tool, skill, and prompt section. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map