/**
 * @deepseek-ai/dsh-deamon — the Deamon host bridge. It owns at most one
 * Windows desktop helper (`sandbox/sandbox-host.ps1`), publishes the helper's
 * base64 JPEG stdout on two faces — a legacy `multipart/x-mixed-replace`
 * response and the WebSocket route the client tab uses, one binary message per
 * frame — and forwards viewport and quit commands through the helper's command
 * file. The helper is shared: every viewer attaches to the running process, and
 * only `POST /stop` ends it. Mouse and keyboard input, window focus/close, and
 * the window/change reads spool through per-instance files beside that command
 * file, and this module fills the change-source seam `shellbox-changes.ts`
 * exposes. The wire format is frozen in `sandbox/PROTOCOL.md`.
 * @module @deepseek-ai/dsh-deamon/sandbox
 */
import { type IncomingMessage, type ServerResponse } from 'node:http';
import type { Context, Logger } from '@deepseek-ai/cordis';
import { DeamonManager } from './deamon-manager.ts';
import type { ShellboxInputEvent, ShellboxStateSnapshot } from './types.ts';
/**
 * Get or initialize the shared DeamonManager for the active session.
 */
export declare function getDeamonManager(log?: Logger): DeamonManager;
/**
 * Test seams. The helper script path is swappable so a spec can drive the bridge
 * against a deterministic stand-in, and the shared controller can be dropped
 * between cases.
 */
export declare const internals: {
    helperScript: string;
    /** Pins the command-file path for a spec; an empty value asks for a fresh temp path. */
    commandFile: string;
    /** Whether to use the isolated Deamon microservice (defaults to true in production). */
    useDaemon: boolean;
    /** Test seam override for daemon manager. */
    daemonManager: DeamonManager | undefined;
    resetController: () => Promise<void>;
};
/**
 * Reassemble complete JPEG payloads from `multipart/x-mixed-replace` bytes.
 *
 * A frame completes when its declared `Content-Length` payload has landed:
 * parts split across chunks stay buffered, bytes before the boundary marker
 * are framing leftovers and are dropped, and a part whose declared length
 * would pass {@link MAX_FRAME_BUFFER_BYTES} — or a header block without a
 * length — resets the buffer so a malformed producer cannot grow memory.
 * @returns a parser whose `push` returns every frame completed by the chunk.
 */
export declare function createMultipartFrameParser(): {
    push(chunk: Buffer): Buffer[];
};
/**
 * Validate a raw `events` JSON value into the helper's input-event union.
 * Rejects anything outside the frozen wire ranges: a non-array, more than
 * {@link MAX_INPUT_EVENTS} entries, coordinates off the {@link MAX_VIEWPORT}
 * canvas, unknown button or press names, non-integer wheel deltas, virtual
 * keys outside 1 through 254, and `char` values that are not UTF-16 code units.
 * @param body - the unparsed `events` value.
 * @returns the validated events in request order, or the first violation's message.
 */
export declare function parseInputEvents(body: unknown): {
    ok: true;
    events: ShellboxInputEvent[];
} | {
    ok: false;
    error: string;
};
/**
 * Read a request body as UTF-8 text.
 * @param req - the request to drain.
 * @returns the concatenated body text.
 */
export declare function readBody(req: IncomingMessage): Promise<string>;
/**
 * Answer a request with JSON.
 * @param res - the response to write.
 * @param status - HTTP status code.
 * @param body - JSON-serializable body.
 */
export declare function respondJson(res: ServerResponse, status: number, body: unknown): void;
export interface SandboxLogger {
    info: (msg: string) => void;
    warn: (msg: string) => void;
    error: (msg: string) => void;
    debug: (msg: string) => void;
}
/**
 * Owner of the single sandbox helper process and of every response attached to
 * it. A helper exit detaches it, so the next stream request starts a fresh one.
 */
export declare class SandboxController {
    private readonly log;
    readonly desktop: string;
    readonly instanceId: string;
    private child;
    private readonly clients;
    /** Partial stdout line held between chunks. */
    private pending;
    /** Viewport requested at helper start, kept so a restarted helper matches the last request. */
    private viewport;
    /** Frame rate requested at helper start, updated when setFps is called. */
    private frameRate;
    private frameTimestamps;
    /**
     * Control channel for the current helper. Windows PowerShell cannot poll stdin
     * without blocking, so commands go through a file the helper drains per frame.
     */
    private commandFile;
    /** Input spool directory of the current helper: `<commandFile>.in`. */
    private inputDir;
    /** Monotonic spool batch sequence within one helper run, starting at 1. */
    private inputSeq;
    /**
     * @param log - diagnostic sink for helper stderr, lifecycle, and exit reports.
     * @param desktop - Win32 private desktop name. Defaults to 'dsh-shellbox'.
     * @param instanceId - bound virtual-instance id whose change ring this controller feeds; empty runs no diff timer.
     */
    constructor(log: SandboxLogger, desktop?: string, instanceId?: string);
    /** True while the helper child process is alive. */
    isActive(): boolean;
    /**
     * The current helper's command file path, whose `.state` sibling holds the
     * helper's window snapshot.
     * @returns the absolute path, or '' before any helper start.
     */
    currentCommandFile(): string;
    /**
     * Return the real-time measured frames per second over recent frames.
     * @returns instantaneous frame rate in frames per second, rounded to 1 decimal place.
     */
    getMeasuredFps(): number;
    /**
     * Attach one response to the shared helper, starting the helper when absent.
     * The response stays open until its client disconnects or the helper exits;
     * ending one attached response never touches another.
     * @param res - the response owning the multipart body.
     */
    stream(res: ServerResponse): void;
    /**
     * Forward a viewport command to the helper's command file.
     * @param width - positive safe integer pixel width.
     * @param height - positive safe integer pixel height.
     * @returns false when no helper is running.
     */
    setViewport(width: number, height: number): boolean;
    /**
     * Return the current frame rate requested from the helper.
     * @returns frame rate in frames per second.
     */
    getFps(): number;
    /**
     * Forward an fps command to the helper's command file.
     * @param fps - frame rate between 1 and 60.
     * @returns false when no helper is running or fps is invalid.
     */
    setFps(fps: number): boolean;
    /**
     * Forward a launch command to the helper's command file, starting the helper when absent.
     * @param command - command line to execute on the Shellbox desktop.
     * @returns true when the command was written to the command file.
     */
    launch(command: string): boolean;
    /**
     * Stop the helper: ask it to quit, then force-kill a process outliving the
     * grace period. Attached responses end first, because the helper destroys
     * its desktop as it exits. The instance's diff timer ends here and its ring
     * records a `desktop-reset`.
     * @returns true when a helper was running and is now stopped.
     */
    stop(): Promise<boolean>;
    /** Spawn the helper when absent; a running one is shared by every stream. */
    private ensureStarted;
    /**
     * Start this instance's ring diff timer once: a 1000 ms interval that runs
     * one snapshot diff pass and then sweeps stale timers, keyed by instance id
     * so helper stop and settle can clear it. A controller outside any instance
     * runs no timer.
     */
    private ensureRingDiffTimer;
    /** Write one command for the helper to drain on its next frame. */
    private writeCommand;
    /**
     * Spool one ordered batch of command lines for the running helper: a single
     * staged file renamed into `<commandFile>.in`, so the helper never observes
     * a partially written batch and drains stay ordered by the padded sequence.
     * @param lines - command lines without line endings, in delivery order.
     * @returns false when no helper is running or the batch could not be staged.
     */
    queueInput(lines: readonly string[]): boolean;
    /**
     * Land a command file atomically. A plain write creates the path before its
     * bytes exist, and the helper polls that path every frame, so a half-written
     * command would be read as empty and deleted.
     */
    private writeAtomically;
    /** Remove a command file, tolerating an already-gone path. */
    private removeCommandFile;
    /** Remove an input spool directory, tolerating an already-gone path. */
    private removeInputDir;
    /** Wire one helper's pipes: frames to attached responses, stderr and exit to the diagnostic log. */
    private attachPipes;
    /**
     * Release one helper: end attached responses and let the next request start
     * a fresh one. The instance's diff timer ends here and its ring records a
     * `desktop-reset`.
     */
    private settleChild;
    /** Detach every listening pipe of a helper the bridge is about to end. */
    private detachPipes;
    /** Split stdout into lines and relay each frame to every attached response. */
    private consumeStdout;
    /** Write one frame part per attached response; a blocked socket drops frames until it drains. */
    private publish;
    /** End every attached multipart response. */
    private endClients;
}
/**
 * Record describing one virtual desktop or Hyper-V environment instance.
 */
export interface VirtualInstanceRecord {
    id: string;
    ownerSessionId: string;
    boundSessionIds: string[];
    type: 'win32' | 'hyperv' | 'wsl-ubuntu';
    name: string;
    desktopName: string;
    vmName?: string | undefined;
    controller: SandboxController;
    createdAt: number;
}
/**
 * Manager coordinating session-scoped sandbox helper processes and virtual instances.
 * Each DSH session can create and bind multiple numbered virtual instances.
 * The 'default' key falls back to the original 'dsh-shellbox' desktop.
 */
export declare class SandboxSessionManager {
    private readonly log;
    private readonly instances;
    private readonly sessionDefault;
    private readonly persistencePath;
    constructor(log: SandboxLogger, options?: {
        persistencePath?: string | false;
    });
    private getDefaultPersistencePath;
    private loadFromDisk;
    private saveToDisk;
    /** Clean session id into safe desktop name suffix (alphanumeric only, max 16 chars). */
    static desktopNameFor(sessionId: string, index?: number): string;
    /** Get or create controller for a session, explicit instance ID, or target type. Defaults to 'default' when empty. */
    get(sessionId?: string, instanceId?: string, target?: string): SandboxController;
    /**
     * Resolve an existing instance without creating one: the read-only twin of
     * {@link get} for window reads and input delivery, which must report a
     * missing desktop instead of materializing it. Unlike `get`, an explicit
     * unknown instance id resolves to undefined rather than falling back to the
     * session default, so a read or an input batch never reaches a desktop the
     * caller did not name.
     * @param sessionId - session key; empty falls back to 'default'.
     * @param instanceId - explicit instance id, when the caller named one.
     * @param target - target kind, when the caller named one.
     * @returns the matching record, or undefined when no such desktop exists.
     */
    find(sessionId?: string, instanceId?: string, target?: string): VirtualInstanceRecord | undefined;
    /**
     * Every instance bound to a session, in registration order.
     * @param sessionId - session key; empty falls back to 'default'.
     * @returns the bound records, empty when the session owns no desktop.
     */
    boundInstances(sessionId: string): VirtualInstanceRecord[];
    /** Create a new numbered instance for a session. */
    createInstance(options: {
        sessionId: string;
        type?: 'win32' | 'hyperv' | 'wsl-ubuntu' | undefined;
        vmName?: string | undefined;
    }): VirtualInstanceRecord;
    /** Attach an existing instance to another session. */
    attachInstance(targetSessionId: string, instanceId: string): boolean;
    /** Detach an instance from a session. */
    detachInstance(sessionId: string, instanceId: string): boolean;
    /** Terminate and cleanup an instance. */
    terminateInstance(instanceId: string): Promise<boolean>;
    /** List all instances across sessions with current status. */
    listInstances(): Array<Omit<VirtualInstanceRecord, 'controller'> & {
        active: boolean;
    }>;
    /** Stop and remove session instances. */
    stop(sessionId?: string): Promise<boolean>;
    /** Stop all running controllers (for teardown/reset). */
    stopAll(): Promise<void>;
    /** Check if a session has an active running helper. */
    hasActive(sessionId?: string): boolean;
}
/** Extract session ID from request URL query or JSON payload. */
export declare function parseSessionParam(req: IncomingMessage, bodyPayload?: unknown): string | undefined;
/** Extract instance ID from request URL query or JSON payload. */
export declare function parseInstanceParam(req: IncomingMessage, bodyPayload?: unknown): string | undefined;
/** Extract target environment type from request URL query or JSON payload. */
export declare function parseTargetParam(req: IncomingMessage, bodyPayload?: unknown): string | undefined;
/** Extract frame rate parameter (1-60 fps) from request URL query or JSON payload. */
export declare function parseFpsParam(req: IncomingMessage, bodyPayload?: unknown): number | undefined;
/**
 * Resolve well-known application aliases (msedge, chrome) to their full executable
 * paths and ensure an isolated user-data-dir is attached so Chromium processes do not
 * defer to existing instances on the interactive desktop.
 */
export declare function resolveLaunchCommand(command: string, desktopName: string): string;
/**
 * Spool one ordered batch of helper command lines for an instance's running
 * helper through that instance's `<commandFile>.in` directory.
 * @param instance - instance whose helper receives the batch.
 * @param lines - command lines without line endings, in delivery order.
 * @returns false when the helper is not running or the batch could not be staged.
 */
export declare function queueShellboxCommands(instance: VirtualInstanceRecord, lines: readonly string[]): boolean;
/**
 * Read an instance's `.state` snapshot beside its command file. The helper
 * renames complete snapshots into place, but a read racing any writer can
 * still see a missing or half-written file: a stat, read, JSON, or shape
 * failure reports nothing rather than a partial desktop.
 * @param instance - instance whose helper owns the snapshot.
 * @returns the parsed snapshot with its file age in milliseconds, or undefined when unreadable.
 */
export declare function readShellboxState(instance: VirtualInstanceRecord): {
    snapshot: ShellboxStateSnapshot;
    ageMs: number;
} | undefined;
/** What a local sandbox route handler hands back for the route to write with `respondJson`. */
export interface SandboxLocalResponse {
    /** HTTP status code the response carries. */
    status: number;
    /** JSON-serializable response body. */
    body: unknown;
}
/**
 * Run one diff pass over an instance's fresh `.state` snapshot: the first pass
 * only stores a silent baseline; later passes append one entry per new, closed,
 * retitled, started, exited, or newly focused window and process. A missing or
 * stale snapshot leaves the stored windows untouched.
 * @param instanceId - instance whose snapshot is compared against its stored baseline.
 */
export declare function drainShellboxStateTick(instanceId: string): void;
/**
 * Serve `GET /api/server/sandbox/windows` locally: the target desktop's
 * liveness plus its latest `.state` snapshot, with `fresh` true only while the
 * snapshot file is younger than {@link STATE_FRESH_MS}. An unknown session or
 * instance answers the documented empty success, never an error.
 * @param manager - the session/instance manager holding the desktops.
 * @param req - the GET request carrying `?session&instance&target`.
 * @returns status 200 with the window response, or 405 for another method.
 */
export declare function handleSandboxWindowsLocal(manager: SandboxSessionManager, req: IncomingMessage): Promise<SandboxLocalResponse>;
/**
 * Serve `POST /api/server/sandbox/input` locally: parse the body, then run
 * {@link deliverShellboxInput}'s status precedence unchanged.
 * @param manager - the session/instance manager holding the desktops.
 * @param req - the POST request; its query may also carry `session`/`instance`.
 * @param bodyText - the already-read request body.
 * @returns status with the `ShellboxInputResult` body.
 */
export declare function handleSandboxInputLocal(manager: SandboxSessionManager, req: IncomingMessage, bodyText: string): Promise<SandboxLocalResponse>;
/**
 * Serve `POST /api/server/sandbox/windows/focus` and `.../windows/close`
 * locally: parse the body, then run {@link deliverShellboxWindowAction}.
 * @param manager - the session/instance manager holding the desktops.
 * @param req - the POST request; its query may also carry `session`/`instance`.
 * @param bodyText - the already-read request body.
 * @param action - which window command to spool for the helper.
 * @returns status with the action result or a refusal body.
 */
export declare function handleSandboxWindowActionLocal(manager: SandboxSessionManager, req: IncomingMessage, bodyText: string, action: 'focus' | 'close'): Promise<SandboxLocalResponse>;
/**
 * Serve `GET /api/server/sandbox/changes` locally: validate the paging cursors,
 * then answer {@link readShellboxChanges}' pure ring page — no cursor of any
 * kind advances here.
 * @param manager - the session/instance manager holding the desktops.
 * @param req - the GET request carrying `?session&instance&since&limit`.
 * @returns status with the ring page, a 400 paging violation, or a 405.
 */
export declare function handleSandboxChangesLocal(manager: SandboxSessionManager, req: IncomingMessage): Promise<SandboxLocalResponse>;
/**
 * Register the sandbox-view routes on the Web server: `GET /stream`,
 * `POST /size`, `POST /launch`, `POST /stop`, and `GET /status`, plus the
 * `WS /ws` upgrade that carries the stream as binary frame messages and the
 * input, window, and change-awareness surface — `POST /input`,
 * `GET /windows`, `POST /windows/focus`, `POST /windows/close`, and
 * `GET /changes`. All registrations support multi-session via `?session=<id>`
 * query parameter or `sessionId` in the JSON request body (the new routes also
 * accept a body `session`/`instance`), and every entry marks its session as
 * Shellbox-touched for the pre-step change pull.
 * @param ctx - plugin context carrying the webServer service.
 */
export declare function registerSandboxRoutes(ctx: Context): void;
/**
 * Register the model-facing `shellbox_launch` tool when the `tools` service is present.
 * @param ctx - plugin context.
 * @param manager - the shared SandboxSessionManager instance.
 */
export declare function registerShellboxTool(ctx: Context, manager: SandboxSessionManager): void;
//# sourceMappingURL=sandbox.d.ts.map