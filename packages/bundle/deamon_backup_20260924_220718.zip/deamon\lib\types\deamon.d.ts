/**
 * Deamon — Independent background HTTP service for desktop streaming
 * and virtualization management.
 *
 * Runs as an isolated Node.js process so that high-framerate MJPEG encoding,
 * GDI window capture pipes, and potential emulator crashes NEVER block or crash
 * DSH's main Node.js process, Web GUI, or Agent loops.
 *
 * @module @deepseek-ai/dsh-deamon/deamon
 */
import { type Server } from 'node:http';
import { SandboxSessionManager } from './sandbox.ts';
export declare const DEFAULT_DEAMON_PORT = 4005;
/** Minimal logger contract for the daemon. */
export interface DaemonLogger {
    info: (msg: string) => void;
    warn: (msg: string) => void;
    error: (msg: string) => void;
    debug: (msg: string) => void;
}
/** Metadata written to disk so DSH or local clients discover the daemon's coordinates. */
export interface DaemonInfo {
    port: number;
    pid: number;
    startedAt: number;
}
/** Configuration options for starting the Deamon service. */
export interface DeamonOptions {
    port?: number | undefined;
    host?: string | undefined;
    log?: DaemonLogger | undefined;
    persistencePath?: string | false | undefined;
}
/** Running daemon handle. */
export interface DeamonHandle {
    server: Server;
    port: number;
    close: () => Promise<void>;
    manager: SandboxSessionManager;
}
/**
 * Resolve the daemon discovery file path: `DEAMON_DISCOVERY_FILE` overrides
 * it so a spec can own its own path, otherwise `$DSH_HOME` or `~/.dsh`.
 */
export declare function getDaemonDiscoveryPath(): string;
/**
 * Start the standalone Deamon HTTP service.
 * @param options - optional port, host, and logger.
 * @returns live handle with server, port, and close method.
 */
export declare function startDeamon(options?: DeamonOptions): Promise<DeamonHandle>;
//# sourceMappingURL=deamon.d.ts.map