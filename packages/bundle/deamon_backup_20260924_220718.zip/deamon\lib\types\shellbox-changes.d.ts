/**
 * Shellbox change awareness: the touched-session seam the host bridge fills in,
 * the pre-step pull that commits desktop changes to the session log, the
 * `shellbox` projection carrying the model's acknowledgment cursor, and the
 * `shellbox_state` / `shellbox_input` tools.
 * @module
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Session } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { ShellboxInputEvent } from './types.js';
/** Reads committed desktop changes and delivers input for one Shellbox session, resolved for daemon or in-process mode. */
export interface ShellboxChangeSource {
    /**
     * Pure ring page read for a session; never advances the model's ack cursor.
     * @param session - session key
     * @param instanceId - desktop instance, or undefined for every instance bound to the session
     * @param since - exclusive ring-id cursor
     * @param limit - maximum entries, 1..200
     * @returns ring page with cursor and active metadata
     */
    readChanges(session: string, instanceId: string | undefined, since: number, limit: number): Promise<import('./types.js').ShellboxChangesResponse>;
    /**
     * Queues validated input events for delivery to the helper.
     * @param session - session key
     * @param instanceId - desktop instance, or undefined for the session default
     * @param events - parsed input events, at most 64
     * @returns delivery result, or a refused status with an HTTP-mappable code
     */
    postInput(session: string, instanceId: string | undefined, events: ShellboxInputEvent[]): Promise<import('./types.js').ShellboxInputResult>;
}
/**
 * Fills the change-source seam; the host bridge calls this once its manager and daemon route exist.
 * @param next - source bound to the live manager and daemon forwarding
 */
export declare function setShellboxChangeSource(next: ShellboxChangeSource): void;
/**
 * The registered change source; misconfiguration fails loud when the bridge never registered one.
 * @returns the live source
 */
export declare function shellboxChangeSource(): ShellboxChangeSource;
/**
 * Marks a session as having at least one live Shellbox desktop, arming pre-step change synchronization for it.
 * @param session - session key
 */
export declare function markShellboxTouched(session: string): void;
/**
 * Whether the session was touched in this process; untouched sessions skip pre-step reads entirely.
 * @param session - session key
 * @returns true when the session has live desktops
 */
export declare function isShellboxTouched(session: string): boolean;
/**
 * Clears the touched mark after a successful change synchronization, so the next sync waits for a new touch or a pending continuation page.
 * @param session - session key
 */
export declare function clearShellboxTouched(session: string): void;
/** One physical line, pinned model-facing copy shown only while unreviewed desktop changes exist. */
export declare const SHELLBOX_CHANGES_LINE = "Shellbox desktop: unreviewed changes happened on the desktop since your last shellbox_state read (a program may have been opened, closed, or renamed). Run shellbox_state to review them before acting.";
/**
 * Model-facing acknowledgment cursor folded from the shellbox change log:
 * `lastSeq` is the seq of the newest committed `shellbox/change`, `ackedSeq`
 * the `throughSeq` of the newest accepted `shellbox/ack`, and `lastRingId` the
 * highest ring id covered by a completed read (the default `since` cursor).
 * Dirty means `lastSeq > ackedSeq`.
 */
export interface ShellboxChangeState {
    /** Seq of the newest committed `shellbox/change` event, -1 before the first one (session seqs start at 0). */
    lastSeq: number;
    /** `throughSeq` of the newest accepted `shellbox/ack` event, -1 when no change has been read yet. */
    ackedSeq: number;
    /** Highest ring id a completed read covered; the next default `since` cursor. */
    lastRingId: number;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** Host shellbox acknowledgment cursor; the key's absence means the deamon bundle is not composed. */
        shellbox: ShellboxChangeState;
    }
}
/**
 * Projection of the committed shellbox change log: registers host-only (no
 * client wire view), so the key exists only while the deamon bundle is
 * composed.
 */
export declare const shellboxProjectionDefinition: {
    key: "shellbox";
    stateVersion: number;
    stateSchema: ProjectionDefinition<"shellbox", ShellboxChangeState>["stateSchema"];
    init: () => {
        lastSeq: number;
        ackedSeq: number;
        lastRingId: number;
    };
    apply: (state: NoInfer<ShellboxChangeState>, event: import("@deepseek-ai/dsh-session").SessionEvent) => ShellboxChangeState;
};
/**
 * The shellbox projection's current cursor state for one session.
 * @param ctx - context used to read the global projection registry.
 * @param session - session whose cursor state is read.
 * @returns the live folded state, or undefined when the projection is not registered.
 */
export declare function shellboxChangeState(ctx: Context, session: Session): ShellboxChangeState | undefined;
/**
 * Pull one change page for a touched (or continuation-pending) session and
 * commit every new entry to the session log as one `shellbox/change` event per
 * desktop instance, then clear the touched mark. Fresh untouched sessions skip
 * entirely; a pending continuation stays due across the touched flag.
 * @param session - live session whose desktops are synchronized.
 * @returns a promise that resolves after the log commits, or rejects loudly when the seam or log refuses.
 */
export declare function syncShellboxChanges(session: Session): Promise<void>;
/**
 * Registers the change-awareness pieces: the awaited `agent/pre-step` pull and
 * the host-only `shellbox` projection registration.
 * @param ctx - plugin context.
 */
export declare function registerShellboxChangeTracking(ctx: Context): void;
/**
 * Registers the model-facing `shellbox_state` change-log reader and
 * `shellbox_input` desktop-input sender when the `tools` service is present.
 * @param ctx - plugin context.
 */
export declare function registerShellboxChangeTools(ctx: Context): void;
//# sourceMappingURL=shellbox-changes.d.ts.map