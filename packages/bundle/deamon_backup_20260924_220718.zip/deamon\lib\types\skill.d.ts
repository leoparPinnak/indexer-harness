/**
 * Bundled `shellbox` skill provider: the Shellbox usage manual the model
 * loads on demand from the skill catalog, and the user reads by typing
 * `/shellbox`.
 *
 * @module @deepseek-ai/dsh-deamon/skill
 */
import { type SkillProvider } from '@deepseek-ai/dsh-skill';
/** The provider the bundle plugin registers on `ctx.skills`. */
export declare const shellboxSkillProvider: SkillProvider;
//# sourceMappingURL=skill.d.ts.map